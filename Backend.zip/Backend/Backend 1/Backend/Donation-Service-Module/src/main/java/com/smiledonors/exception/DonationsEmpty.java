package com.smiledonors.exception;

public class DonationsEmpty extends RuntimeException{



    public DonationsEmpty(String s) {
    super(s);
    }
}
